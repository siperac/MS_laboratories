# Precisation 


The proof of the correct carry generation has been done testing separately the carry generator.

Observing the resulting simulation of the ripple carry adder (RCA) it can be seen
that the the difference among S1, S2 and S3 is that the result is not the correct result of the 
arithmetic operation but it shows only 6 LSB.
The addition 53 + 21 would need 7 bits  to be represented and because of this the  CoX are set to 1.
